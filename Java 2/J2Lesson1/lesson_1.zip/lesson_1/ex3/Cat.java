////Инкапсуляция
//
//public class Cat {
//    public static int weight;
//    private  String name;
//    private int age;
//
//    //
//
//    public void setAge(int age) {
//        if (age > 0)
//            this.age = age;
//        else
//            System.out.println("Введен некорректный возраст");
//    }
//    public int getAge() {
//        return age;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//    public String getName() {
//        return name;
//    }
//
//
//}
//class Cat2 extends Cat{
//    public static void main(String[] args) {
//        Cat2 cat2 = new Cat2();
//        cat2.weight = 10;
//        cat2.setAge(10);
//    }
//}
//
