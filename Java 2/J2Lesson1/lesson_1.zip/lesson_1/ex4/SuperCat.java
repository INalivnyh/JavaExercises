//public class SuperCat extends Cat {
//    private int c;
//    public SuperCat(int a,int b, int c) {
//        super(a, b);    // первым делом вызываем конструктор Cat
//        this.c = c;
//    }
//}


/*
SuperCat sc = new SuperCat();
Animal() => Cat() => SuperCat()
 */