//public class Animal {
//    void voice() {
//        System.out.println("Животное издало звук");
//    }
//}

