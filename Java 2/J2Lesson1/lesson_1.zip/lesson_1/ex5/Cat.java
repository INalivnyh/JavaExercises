//public class Cat extends Animal {
//    @Override
//    void voice() {
//        System.out.println("Кот мяукнул");
//    }
//}



//public class Cat extends Animal {
//    @Override
//    public void voice() {
//        super.voice(); // вызываем метод voice() суперкласса
//        System.out.println("Кот мяукнул");
//    }
//}


