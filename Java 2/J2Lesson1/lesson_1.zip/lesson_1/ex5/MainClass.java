//public class MainClass {
//    public static void main(String[] args) {
//        Animal a = new Animal();
//        Cat c = new Cat();
//        a.voice();
//        c.voice();
//    }
//}

