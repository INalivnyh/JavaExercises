//public abstract class Animal {
//    public abstract void voice();
//    public void jump() {
//        System.out.println("Животное подпрыгнуло");
//    }
//}

