//public class Cat extends Animal {
//    @Override
//    public void voice() {
//        System.out.println("Кот мяукнул");
//    }
//}
