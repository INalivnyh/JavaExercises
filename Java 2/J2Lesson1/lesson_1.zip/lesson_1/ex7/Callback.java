public interface Callback {
    void callback(int param);

}
