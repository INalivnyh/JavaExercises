public class ClientTwo implements Callback {
    public void callback(int param) {
        System.out.println("ClientTwo param: " + param);
    }
}