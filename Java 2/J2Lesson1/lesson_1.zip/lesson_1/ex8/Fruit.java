//public enum Fruit {
//    ORANGE,
//    APPLE,
//    BANANA,
//    CHERRY;

//    public static void main(String[] args) {
//        Fruit f = Fruit.APPLE;
//        System.out.println(f);
//        if (f == Fruit.APPLE) {
//            System.out.println("f действительно является яблоком");
//        }
//        switch (f) {
//            case APPLE:
//                System.out.println("f - яблоко");
//                break;
//            case ORANGE:
//                System.out.println("f - апельсин");
//                break;
//            case CHERRY:
//                System.out.println("f - вишня");
//                break;
//        }
//    }
//}

    //values() и valueOf()

//    public static void main(String[] args) {
//        System.out.println("Все элементы перечисления:");
//        for(Fruit o : Fruit.values()) {
//            System.out.println(o);
//        }
//        System.out.println("Поиск элемента по названию: " + Fruit.valueOf("BANANA"));
//    }
//
//}

