//public enum Fruit_2 {
//    ORANGE("Апельсин", 3), APPLE("Яблоко", 3), BANANA("Банан", 2), CHERRY("Вишня", 1);
//    private String rus;
//    private int weight;
//    public String getRus() {
//        return rus;
//    }
//    public int getWeight() {
//        return weight;
//    }
//    Fruit_2(String rus, int weight) {
//        this.rus = rus;
//        this.weight = weight;
//    }
//}
//class Main {
//    public static void main(String[] args) {
//        for(Fruit_2 o : Fruit_2.values()) {
//            System.out.printf("Средний вес фрукта %s составляет: %d ед.\n", o.getRus(), o.getWeight());
//        }
//    }
//}
